import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  projectId: 'agendamento-riyys',
  appId: '1:829339764281:web:5f5605365c03b92ebcafe8',
  storageBucket: 'agendamento-riyys.firebasestorage.app',
  apiKey: 'AIzaSyCovGkocuvxB9mJbnAQ0_rTMxDEtq-t9hg',
  authDomain: 'agendamento-riyys.firebaseapp.com',
  measurementId: '',
  messagingSenderId: '829339764281',
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);

export { app, db };
