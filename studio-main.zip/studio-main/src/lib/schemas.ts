import { z } from 'zod';
import { JOB_FUNCTION_NAMES, RANK_NAMES, TEAM_NAMES } from './types';

export const LoginSchema = z.object({
  email: z.string().email({
    message: 'Por favor, insira um endereço de e-mail válido.',
  }),
  password: z.string().min(1, {
    message: 'A senha é obrigatória.',
  }),
});

const rgMask = (value: string) => {
  if (!value) return '';
  const onlyNumbers = value.replace(/\D/g, '');
  if (onlyNumbers.length > 9) {
    return onlyNumbers.slice(0, 9);
  }
  return onlyNumbers
    .replace(/(\d{2})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})([a-zA-Z0-9]{1,2})$/, '$1-$2');
};

const taxIdMask = (value: string) => {
  return value
    .replace(/\D/g, '')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d{1,2})/, '$1-$2')
    .slice(0, 14);
};

const phoneMask = (value: string) => {
  return value
    .replace(/\D/g, '')
    .replace(/(\d{2})(\d)/, '($1) $2')
    .replace(/(\d{5})(\d)/, '$1-$2')
    .slice(0, 15);
};

const timeMask = (value: string) => {
  return value
    .replace(/\D/g, '')
    .replace(/(\d{2})(\d)/, '$1:$2')
    .slice(0, 5);
};

export const TeamHistoryEntrySchema = z.object({
    team: z.enum(TEAM_NAMES),
    effectiveDate: z.string(), // ISO String
});

export const SignupSchema = z.object({
  photo: z.string().optional().or(z.literal('')),
  rank: z.string().min(1, "Selecione um Posto/Graduação"),
  rg: z.string().min(1, 'A Identidade é obrigatória.'),
  nickname: z.string().min(1, 'O Nome de Guerra é obrigatório.'),
  fullName: z.string().min(1, 'O Nome Completo é obrigatório.'),
  jobFunction: z.string().optional().or(z.literal('')),
  workTeam: z.string().optional().or(z.literal('')),
  taxId: z.string().refine(value => value.replace(/\D/g, '').length === 11, {
    message: 'O CPF deve ter 11 dígitos.',
  }),
  phone: z.string().refine(value => value.replace(/\D/g, '').length >= 10, {
    message: 'O telefone deve ter pelo menos 10 dígitos.',
  }),
  email: z.string().email('Por favor, insira um endereço de e-mail válido.'),
  password: z.string().min(8, 'A senha deve ter pelo menos 8 caracteres.'),
  presentationDate: z.preprocess(
    (arg) => (arg ? new Date(arg as string) : undefined),
    z.date().optional()
  ),
});

export const UpdateUserSchema = SignupSchema.omit({ taxId: true, email: true, workTeam: true }).extend({
    password: z.string().min(8, 'A nova senha deve ter pelo menos 8 caracteres.').optional().or(z.literal('')),
    sortOrder: z.coerce.number().optional(),
    teamHistory: z.array(TeamHistoryEntrySchema).optional(),
});

export const ForgotPasswordSchema = z.object({
  email: z.string().email({
    message: 'Por favor, insira um endereço de e-mail válido.',
  }),
});

export const ScheduleSchema = z.object({
    scheduleName: z.string().min(1, 'O nome da escala é obrigatório.'),
    startTime: z.string().min(1, 'O horário de início é obrigatório.'),
    endTime: z.string().min(1, 'O horário de término é obrigatório.'),
    capacity: z.coerce.number({invalid_type_error: "A capacidade é obrigatória."}).min(1, 'A capacidade deve ser de no mínimo 1.'),
    dates: z.array(z.date()).min(1, 'Selecione pelo menos um dia no calendário.'),
});

export const UpdateScheduleSchema = ScheduleSchema.omit({ dates: true });

export const Ac4RatesSchema = z.object({
    blueDay: z.coerce.number({ required_error: 'O valor é obrigatório.' }).min(0, 'O valor deve ser positivo.'),
    blueNight: z.coerce.number({ required_error: 'O valor é obrigatório.' }).min(0, 'O valor deve ser positivo.'),
    redDay: z.coerce.number({ required_error: 'O valor é obrigatório.' }).min(0, 'O valor deve ser positivo.'),
    redNight: z.coerce.number({ required_error: 'O valor é obrigatório.' }).min(0, 'O valor deve ser positivo.'),
});

export const Ac4SimulatorSchema = z.object({
  date: z.date({
    required_error: "A data é obrigatória.",
  }),
  startTime: z.string().min(1, 'O horário de início é obrigatório.').regex(/^([01]\d|2[0-3]):?([0-5]\d)$/, 'Formato de hora inválido. Use HH:mm.'),
  endTime: z.string().min(1, 'O horário de término é obrigatório.').regex(/^([01]\d|2[0-3]):?([0-5]\d)$/, 'Formato de hora inválido. Use HH:mm.'),
});

export const ExternalScheduleSchema = z.object({
    scheduleName: z.string().min(1, 'A descrição é obrigatória.'),
    date: z.date({
      required_error: "A data é obrigatória.",
    }),
    startTime: z.string().min(1, 'O horário de início é obrigatório.').regex(/^([01]\d|2[0-3]):?([0-5]\d)$/, 'Formato de hora inválido. Use HH:mm.'),
    endTime: z.string().min(1, 'O horário de término é obrigatório.').regex(/^([01]\d|2[0-3]):?([0-5]\d)$/, 'Formato de hora inválido. Use HH:mm.'),
  });

export const maskFunctions = {
  rg: rgMask,
  taxId: taxIdMask,
  phone: phoneMask,
  time: timeMask,
}

export const ScheduleSettingsSchema = z.object({
    schedulingStartDate: z.preprocess((arg) => (arg ? new Date(arg as string) : null), z.date().optional().nullable()),
    schedulingStartTime: z.string().optional(),
    schedulingEndDate: z.preprocess((arg) => (arg ? new Date(arg as string) : null), z.date().optional().nullable()),
    schedulingEndTime: z.string().optional(),
    maxSchedulesPerUser: z.coerce.number().optional().nullable(),
}).superRefine((data, ctx) => {
    if (data.schedulingStartDate && !data.schedulingStartTime) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['schedulingStartTime'],
        message: 'A hora de início é obrigatória se a data de início for definida.',
      });
    }
    if (data.schedulingEndDate && !data.schedulingEndTime) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['schedulingEndTime'],
        message: 'A hora final é obrigatória se a data final for definida.',
      });
    }
  
    if (data.schedulingStartDate && data.schedulingEndDate && data.schedulingStartTime && data.schedulingEndTime) {
      const startDateTime = new Date(data.schedulingStartDate);
      const [sH, sM] = data.schedulingStartTime.split(':').map(Number);
      startDateTime.setHours(sH, sM, 0, 0);
  
      const endDateTime = new Date(data.schedulingEndDate);
      const [eH, eM] = data.schedulingEndTime.split(':').map(Number);
      endDateTime.setHours(eH, eM, 0, 0);
  
      if (endDateTime < startDateTime) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['schedulingEndDate'],
          message: 'O período final deve ser posterior ou igual ao período inicial.',
        });
      }
    }
  });

export const AbsenceSchema = z.object({
  id: z.string().optional().nullable(),
  officerId: z.string().min(1, 'Selecione um policial.'),
  reason: z.string().min(1, 'Selecione o tipo de afastamento.'),
  startDate: z.preprocess((arg) => (arg ? new Date(arg as string) : undefined), z.date({ required_error: 'A data de início é obrigatória.' })),
  endDate: z.preprocess((arg) => (arg ? new Date(arg as string) : undefined), z.date({ required_error: 'A data de fim é obrigatória.' })),
}).refine(data => data.endDate >= data.startDate, {
  message: 'A data de fim deve ser posterior ou igual à data de início.',
  path: ['endDate'],
});

export const PontuacaoSchema = z.object({
    notaCfsc: z.coerce.number().default(0),
    notaCfc: z.coerce.number().default(0),
    notaCas: z.coerce.number().default(0),
    notaCfs: z.coerce.number().default(0),
    cursoAtualizacao: z.coerce.number().default(0),
    cursoGraduacao: z.boolean().default(false),
    cursoPosGraduacao: z.boolean().default(false),
    cursoDoutorado: z.boolean().default(false),
    elogioMeritorio: z.coerce.number().default(0),
    efetivoAno: z.coerce.number().default(0),
    efetivoMes: z.coerce.number().default(0),
    efetivoDia: z.coerce.number().default(0),
    afastamentoAno: z.coerce.number().default(0),
    afastamentoMes: z.coerce.number().default(0),
    afastamentoDia: z.coerce.number().default(0),
    medalhaDomPedro: z.boolean().default(false),
    medalhaTiradentes: z.boolean().default(false),
    medalhaAnhanguera: z.boolean().default(false),
    medalhaMeritoPolicial: z.boolean().default(false),
    medalhaMeritoMagisterio: z.boolean().default(false),
    medalhaMeritoIntelectual: z.boolean().default(false),
    medalhaGuardiao: z.boolean().default(false),
    medalhaSSP: z.boolean().default(false),
    medalhaServicoDistinto: z.boolean().default(false),
    anhangueraBronze: z.boolean().default(false),
    anhangueraPrata: z.boolean().default(false),
    anhangueraOuro: z.boolean().default(false),
    tempo10anos: z.boolean().default(false),
    tempo20anos: z.boolean().default(false),
    tempo30anos: z.boolean().default(false),
    medalha150anos: z.boolean().default(false),
    outrasCondecoracoes: z.coerce.number().default(0),
    taf: z.string().default('0'),
    crimeDoloso: z.coerce.number().default(0),
    crimeCulposo: z.coerce.number().default(0),
    prisaoDisciplinar: z.coerce.number().default(0),
    detencaoDisciplinar: z.coerce.number().default(0),
    repreensao: z.coerce.number().default(0),
});

export type FormValues = z.infer<typeof PontuacaoSchema>;
