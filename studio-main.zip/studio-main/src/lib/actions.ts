'use server';

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { 
  collection, 
  query, 
  where, 
  getDocs, 
  doc, 
  getDoc, 
  setDoc, 
  writeBatch, 
  updateDoc, 
  arrayUnion, 
  arrayRemove, 
  Timestamp, 
  documentId, 
  deleteDoc 
} from 'firebase/firestore';
import { 
  LoginSchema, 
  SignupSchema, 
  ScheduleSchema, 
  UpdateUserSchema, 
  UpdateScheduleSchema, 
  Ac4RatesSchema, 
  ScheduleSettingsSchema, 
  AbsenceSchema 
} from './schemas';
import { db } from './firebase';
import { revalidatePath } from 'next/cache';
import type { UserData, Ac4Rates, ScheduleSettings, Absence, Schedule, Pontuacao, FormState } from '@/lib/types';
import { TeamHistoryEntry } from '@/lib/types';
import { format } from 'date-fns';
import { capitalizeName } from './utils';

export async function isAdmin(userId: string | undefined): Promise<boolean> {
  if (!userId) return false;
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (userDoc.exists()) {
      const admins = (process.env.ADMIN_EMAILS || '').split(',');
      return admins.includes(userDoc.data().email);
    }
    return false;
  } catch { return false; }
}

export async function loginAction(prevState: FormState, formData: FormData): Promise<FormState> {
  const vals = LoginSchema.safeParse(Object.fromEntries(formData));
  if (!vals.success) return { message: 'Campos inválidos.', success: false };
  const { email, password } = vals.data;
  try {
    const q = query(collection(db, 'users'), where("email", "==", email));
    const snap = await getDocs(q);
    if (snap.empty || snap.docs[0].data().password !== password) return { message: 'Credenciais inválidas.', success: false };
    const user = snap.docs[0];
    const cookieStore = await cookies();
    cookieStore.set('user_id', user.id, { httpOnly: true, secure: true, maxAge: 86400, path: '/' });
    if (await isAdmin(user.id)) redirect('/admin/dashboard');
    else redirect('/dashboard');
  } catch (e: any) { if (e.message === 'NEXT_REDIRECT') throw e; return { message: 'Erro ao entrar.', success: false }; }
}

export async function signupAction(prevState: FormState, formData: FormData): Promise<FormState> {
  const vals = SignupSchema.safeParse(Object.fromEntries(formData));
  if (!vals.success) return { message: vals.error.errors[0].message, success: false };
  const userId = vals.data.taxId.replace(/\D/g, '');
  try {
    const userRef = doc(db, 'users', userId);
    if ((await getDoc(userRef)).exists()) return { message: 'CPF já cadastrado.', success: false };
    const initialHistory: TeamHistoryEntry[] = vals.data.workTeam 
        ? [{ team: vals.data.workTeam as any, effectiveDate: new Date().toISOString() }] 
        : [];
    await setDoc(userRef, { 
      ...vals.data, 
      taxId: userId, 
      rg: vals.data.rg.replace(/\D/g, ''), 
      phone: vals.data.phone.replace(/\D/g, ''), 
      nickname: capitalizeName(vals.data.nickname), 
      fullName: capitalizeName(vals.data.fullName), 
      teamHistory: initialHistory, 
      sortOrder: 999, 
      presentationDate: new Date().toISOString() 
    });
    return { message: 'Cadastro realizado!', success: true };
  } catch { return { message: 'Erro ao cadastrar.', success: false }; }
}

export async function logoutAction() {
  const cookieStore = await cookies();
  cookieStore.delete('user_id');
  redirect('/');
}

export async function getUserDataById(userId: string): Promise<UserData | null> {
    try {
        const snap = await getDoc(doc(db, 'users', userId));
        if (!snap.exists()) return null;
        const d = snap.data();
        return { 
          id: snap.id, 
          photo: d.photo || '', 
          rank: d.rank || '', 
          nickname: d.nickname || '', 
          rg: d.rg || '', 
          fullName: d.fullName || '', 
          jobFunction: d.jobFunction || '', 
          taxId: d.taxId || snap.id, 
          phone: d.phone || '', 
          teamHistory: d.teamHistory || [], 
          email: d.email || '', 
          sortOrder: d.sortOrder ?? 999, 
          presentationDate: d.presentationDate 
        };
    } catch { return null; }
}

export async function getUsersByIds(userIds: string[]): Promise<UserData[]> {
    if (!userIds || userIds.length === 0) return [];
    try {
        const q = query(collection(db, 'users'), where(documentId(), 'in', userIds));
        const snap = await getDocs(q);
        return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as UserData));
    } catch { return []; }
}

export async function saveScheduleAction(prevState: FormState, formData: FormData): Promise<FormState> {
    const raw = Object.fromEntries(formData);
    const datesStr = raw.dates as string;
    const dates = datesStr ? datesStr.split(',').filter(Boolean).map(d => new Date(d)) : [];
    
    // Server-side validation with proper error logging
    const vals = ScheduleSchema.safeParse({ ...raw, capacity: Number(raw.capacity), dates });
    if (!vals.success) {
        console.error('Save schedule validation failed:', vals.error.flatten());
        return { message: 'Campos inválidos.', success: false };
    }
    
    const { startTime, endTime, scheduleName, capacity } = vals.data;

    try {
      const batch = writeBatch(db);
      for (const d of dates) {
        const scheduleDateString = format(d, 'yyyy-MM-dd');
        // Força offset de Brasília (-03:00) na criação do objeto Date para evitar erro das 3 horas
        const startDateTime = new Date(`${scheduleDateString}T${startTime}:00-03:00`);
        let endDateTime = new Date(`${scheduleDateString}T${endTime}:00-03:00`);
        
        if (endDateTime <= startDateTime) {
          endDateTime.setDate(endDateTime.getDate() + 1);
        }

        const id = `${scheduleDateString}_${scheduleName.replace(/\s+/g, '-')}_${Math.random().toString(36).substr(2, 5)}`;
        batch.set(doc(db, 'schedules', id), { 
          scheduleName, 
          startTime: Timestamp.fromDate(startDateTime), 
          endTime: Timestamp.fromDate(endDateTime), 
          capacity, 
          userIds: [], 
          status: 'active' 
        });
      }
      await batch.commit();
      revalidatePath('/admin/dashboard');
      return { message: 'Escalas salvas!', success: true };
    } catch (e) { 
        console.error('Error saving schedule batch:', e);
        return { message: 'Erro ao salvar escalas.', success: false }; 
    }
}

export async function signUpForScheduleAction(scheduleId: string): Promise<FormState> {
    const cookieStore = await cookies();
    const userId = cookieStore.get('user_id')?.value;
    if (!userId) return { message: 'Acesse sua conta.', success: false };
    try {
        const ref = doc(db, 'schedules', scheduleId);
        const snap = await getDoc(ref);
        if (!snap.exists()) return { message: 'Não encontrada.', success: false };
        const data = snap.data();
        if ((data.userIds || []).length >= data.capacity) return { message: 'Escala lotada.', success: false };
        
        const settings = await getScheduleSettings();
        if (settings.maxSchedulesPerUser) {
            const q = query(collection(db, 'schedules'), where('userIds', 'array-contains', userId), where('status', '==', 'active'));
            const userSchedules = await getDocs(q);
            const start = new Date(data.startTime.toDate());
            start.setDate(1);
            start.setHours(0,0,0,0);
            const end = new Date(start);
            end.setMonth(end.getMonth() + 1);
            
            const count = userSchedules.docs.filter(d => {
              const dTime = d.data().startTime.toDate();
              return dTime >= start && dTime < end;
            }).length;
            
            if (count >= settings.maxSchedulesPerUser) return { message: 'Limite mensal atingido.', success: false };
        }
        await updateDoc(ref, { userIds: arrayUnion(userId) });
        revalidatePath('/agendamento');
        return { message: 'Inscrição confirmada!', success: true };
    } catch { return { message: 'Erro ao processar inscrição.', success: false }; }
}

export async function cancelSignUpAction(scheduleId: string): Promise<FormState> {
    const cookieStore = await cookies();
    const userId = cookieStore.get('user_id')?.value;
    if (!userId) return { message: 'Acesse sua conta.', success: false };
    try {
        await updateDoc(doc(db, 'schedules', scheduleId), { userIds: arrayRemove(userId) });
        revalidatePath('/dashboard');
        revalidatePath('/agendamento');
        return { message: 'Cancelado com sucesso.', success: true };
    } catch { return { message: 'Erro ao cancelar.', success: false }; }
}

export async function updateUserAction(userId: string, prevState: any, formData: FormData): Promise<FormState> {
  let history = [];
  try { history = JSON.parse(formData.get('teamHistory') as string || '[]'); } catch {}
  const raw = Object.fromEntries(formData);
  const vals = UpdateUserSchema.safeParse({ ...raw, sortOrder: Number(raw.sortOrder) || 999, teamHistory: history });
  if (!vals.success) return { message: 'Dados inválidos.', success: false };
  try {
    const { password, ...data } = vals.data;
    const upd: any = { 
      ...data, 
      fullName: capitalizeName(data.fullName), 
      nickname: capitalizeName(data.nickname), 
      phone: data.phone.replace(/\D/g, ''), 
      rg: data.rg.replace(/\D/g, '') 
    };
    if (password) upd.password = password;
    await updateDoc(doc(db, 'users', userId), upd);
    revalidatePath('/admin/dashboard');
    return { message: 'Perfil atualizado!', success: true };
  } catch { return { message: 'Erro ao atualizar perfil.', success: false }; }
}

export async function getScheduleSettings(): Promise<ScheduleSettings> {
  const snap = await getDoc(doc(db, 'settings', 'scheduleSettings'));
  if (snap.exists()) return snap.data() as ScheduleSettings;
  return { schedulingStartDate: null, schedulingEndDate: null, maxSchedulesPerUser: null };
}

export async function updateScheduleSettingsAction(prevState: any, fd: FormData): Promise<FormState> {
    const raw = Object.fromEntries(fd);
    
    const createIso = (date: Date | null | undefined, time: string): string | null => {
        if (!date) return null;
        const dateStr = format(date, 'yyyy-MM-dd');
        return new Date(`${dateStr}T${time || '00:00'}:00-03:00`).toISOString();
    };

    try {
        const startVal = raw.schedulingStartDate ? new Date(raw.schedulingStartDate as string) : null;
        const endVal = raw.schedulingEndDate ? new Date(raw.schedulingEndDate as string) : null;

        await setDoc(doc(db, 'settings', 'scheduleSettings'), { 
            schedulingStartDate: createIso(startVal, raw.schedulingStartTime as string),
            schedulingEndDate: createIso(endVal, raw.schedulingEndTime as string),
            maxSchedulesPerUser: raw.maxSchedulesPerUser ? Number(raw.maxSchedulesPerUser) : null
        }, { merge: true });
        revalidatePath('/agendamento');
        return { message: 'Configurações salvas.', success: true };
    } catch { return { message: 'Erro ao salvar configurações.', success: false }; }
}

export async function getAc4Rates(): Promise<Ac4Rates> {
  const snap = await getDoc(doc(db, 'settings', 'ac4Rates'));
  return snap.exists() ? snap.data() as Ac4Rates : { blueDay: 26.47, blueNight: 29.80, redDay: 36.41, redNight: 41.38 };
}

export async function updateAc4RatesAction(prevState: any, formData: FormData): Promise<FormState> {
    const raw = Object.fromEntries(formData);
    const vals = Ac4RatesSchema.safeParse(raw);
    if (!vals.success) return { message: 'Valores inválidos.', success: false };
    try {
        await setDoc(doc(db, 'settings', 'ac4Rates'), vals.data);
        return { message: 'Valores atualizados.', success: true };
    } catch { return { message: 'Erro ao salvar valores.', success: false }; }
}

export async function getAllUsers(): Promise<UserData[]> {
    const snap = await getDocs(collection(db, 'users'));
    return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as UserData));
}

export async function getAbsences(): Promise<Absence[]> {
    const snap = await getDocs(collection(db, 'absences'));
    return snap.docs.map(doc => {
        const d = doc.data();
        return { 
          id: doc.id, 
          officerId: d.officerId, 
          reason: d.reason, 
          startDate: d.startDate.toDate().toISOString(), 
          endDate: d.endDate.toDate().toISOString() 
        };
    });
}

export async function addOrUpdateAbsenceAction(formData: FormData): Promise<FormState> {
    const raw = Object.fromEntries(formData);
    const vals = AbsenceSchema.safeParse(raw);
    if (!vals.success) return { message: 'Campos inválidos.', success: false };
    try {
        const data = { 
          officerId: vals.data.officerId, 
          reason: vals.data.reason, 
          startDate: Timestamp.fromDate(new Date(vals.data.startDate)), 
          endDate: Timestamp.fromDate(new Date(vals.data.endDate)) 
        };
        if (vals.data.id) await updateDoc(doc(db, 'absences', vals.data.id), data);
        else await setDoc(doc(collection(db, 'absences')), data);
        revalidatePath('/admin/dashboard');
        return { message: 'Afastamento salvo.', success: true };
    } catch { return { message: 'Erro ao salvar afastamento.', success: false }; }
}

export async function deleteAbsenceAction(id: string): Promise<FormState> {
    try {
        await deleteDoc(doc(db, 'absences', id));
        revalidatePath('/admin/dashboard');
        return { message: 'Excluído com sucesso.', success: true };
    } catch { return { message: 'Erro ao excluir afastamento.', success: false }; }
}

export async function deleteScheduleAction(id: string): Promise<FormState> {
    try {
        await updateDoc(doc(db, 'schedules', id), { status: 'canceled' });
        revalidatePath('/admin/dashboard');
        return { message: 'Escala cancelada.', success: true };
    } catch { return { message: 'Erro ao cancelar escala.', success: false }; }
}

export async function updateVolunteersAction(id: string, userIds: string[]): Promise<FormState> {
    try {
        await updateDoc(doc(db, 'schedules', id), { userIds });
        revalidatePath('/admin/dashboard');
        return { message: 'Voluntários atualizados.', success: true };
    } catch { return { message: 'Erro ao atualizar voluntários.', success: false }; }
}

export async function updateScheduleAction(id: string, prevState: any, formData: FormData): Promise<FormState> {
    const raw = Object.fromEntries(formData);
    const vals = UpdateScheduleSchema.safeParse({ ...raw, capacity: Number(raw.capacity) });
    if (!vals.success) return { message: 'Dados inválidos.', success: false };
    try {
        const snap = await getDoc(doc(db, 'schedules', id));
        if (!snap.exists()) return { message: 'Não encontrada.', success: false };
        const baseDate = format(snap.data().startTime.toDate(), 'yyyy-MM-dd');
        
        const start = new Date(`${baseDate}T${vals.data.startTime}:00-03:00`);
        let end = new Date(`${baseDate}T${vals.data.endTime}:00-03:00`);
        
        if (end <= start) {
          end.setDate(end.getDate() + 1);
        }

        await updateDoc(doc(db, 'schedules', id), { 
          scheduleName: vals.data.scheduleName, 
          startTime: Timestamp.fromDate(start), 
          endTime: Timestamp.fromDate(end), 
          capacity: vals.data.capacity 
        });
        revalidatePath('/admin/dashboard');
        return { message: 'Escala atualizada.', success: true };
    } catch { return { message: 'Erro ao atualizar escala.', success: false }; }
}

export async function bulkCreateUsersAction(users: any[]): Promise<FormState> {
    try {
        const batch = writeBatch(db);
        let count = 0;
        for (const u of users) {
            const taxId = u.taxId.replace(/\D/g, '');
            const ref = doc(db, 'users', taxId);
            batch.set(ref, { 
              ...u, 
              taxId, 
              rg: u.rg.replace(/\D/g, ''), 
              phone: u.phone.replace(/\D/g, ''), 
              nickname: capitalizeName(u.nickname), 
              fullName: capitalizeName(u.fullName), 
              teamHistory: u.workTeam ? [{ team: u.workTeam, effectiveDate: new Date().toISOString() }] : [], 
              sortOrder: 999, 
              presentationDate: new Date().toISOString() 
            });
            count++;
        }
        await batch.commit();
        return { message: `${count} usuários criados com sucesso.`, success: true, count };
    } catch { return { message: 'Erro na importação em massa.', success: false }; }
}

export async function forgotPasswordAction(prevState: any, formData: FormData): Promise<FormState> {
    return { message: 'Se o e-mail existir no sistema, as instruções foram enviadas.', success: true };
}

export async function getPontuacaoAction(): Promise<{ success: boolean; data?: Pontuacao; message?: string }> {
    const cookieStore = await cookies();
    const userId = cookieStore.get('user_id')?.value;
    if (!userId) return { success: false, message: 'Não autenticado.' };
    try {
        const snap = await getDoc(doc(db, 'pontuacoes', userId));
        return { success: true, data: snap.exists() ? snap.data() as Pontuacao : undefined };
    } catch { return { success: false, message: 'Erro ao carregar pontuação.' }; }
}

export async function savePontuacaoAction(data: Pontuacao): Promise<FormState> {
    const cookieStore = await cookies();
    const userId = cookieStore.get('user_id')?.value;
    if (!userId) return { message: 'Não autenticado.', success: false };
    try {
        await setDoc(doc(db, 'pontuacoes', userId), data);
        return { message: 'Pontuação salva com sucesso!', success: true };
    } catch { return { message: 'Erro ao salvar pontuação.', success: false }; }
}
