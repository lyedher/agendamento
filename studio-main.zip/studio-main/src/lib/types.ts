import type { UserData as BaseUserData } from "@/components/layout/user-profile";
import type { FormValues } from "./schemas";

export type TeamHistoryEntry = {
    team: Team;
    effectiveDate: string; // ISO string
};

export type UserData = Omit<BaseUserData, 'workTeam'> & {
    presentationDate?: string; // ISO string
    teamHistory?: TeamHistoryEntry[];
};

export type Schedule = {
    id: string;
    scheduleName: string;
    startTime: string; // ISO 8601 string
    endTime: string; // ISO 8601 string
    capacity: number;
    userIds: string[];
    volunteers: UserData[];
    status?: 'active' | 'canceled';
};

export type VolunteerSchedule = {
    volunteerId: string;
    rg: string;
    nickname: string;
    workTeam: string;
    scheduleName:string;
    scheduleDate: string;
    scheduleTime: string;
    startTime: string; // ISO 8601 string
}

export type FormState = {
  message: string;
  success: boolean;
  count?: number;
};

export const RANK_NAMES = [
    'Coronel', 'Tenente-Coronel', 'Major', 'Capitão', 
    '1º Tenente', '2º Tenente', 'Aspirante', 'Subtenente', 
    '1º Sargento', '2º Sargento', '3º Sargento', 'Cabo', 'Soldado'
] as const;
export type Rank = (typeof RANK_NAMES)[number];

export const TEAM_NAMES = ['ALPHA', 'BRAVO', 'CHARLIE', 'DELTA', 'ADM', 'AFASTADO'] as const;
export const ROTATION_TEAM_NAMES = ['CHARLIE', 'DELTA', 'ALPHA', 'BRAVO'] as const;
export type Team = (typeof TEAM_NAMES)[number];

export const JOB_FUNCTION_NAMES = [
    'Motorista VTR', 'Comandante VTR', 'CPU', 
    'Plantonista', 'Auxiliar de Secção', 'Chefe de Secção'
] as const;
export type JobFunction = (typeof JOB_FUNCTION_NAMES)[number];

export const ABSENCE_TYPES = [
    'Férias', 'Atestado Médico', 'Licença Especial', 
    'LTS', 'Dispensa Recompensa', 'Cursos', 'Núpcias', 'Luto'
] as const;
export type AbsenceType = (typeof ABSENCE_TYPES)[number];

export type Absence = {
    id: string;
    officerId: string;
    startDate: string; // ISO Date string
    endDate: string; // ISO Date string
    reason: AbsenceType;
};

export type Ac4Rates = {
    blueDay: number;
    blueNight: number;
    redDay: number;
    redNight: number;
};

export type Ac4Calculation = {
    scheduleName: string;
    startTime: string; // ISO string
    totalValue: number;
    details: {
        type: 'blueDay' | 'blueNight' | 'redDay' | 'redNight';
        hours: number;
        value: number;
    }[];
    isExternal?: boolean;
};

export type ScheduleSettings = {
    schedulingStartDate?: string | null;
    schedulingEndDate?: string | null;
    maxSchedulesPerUser?: number | null;
};

export type Pontuacao = FormValues;

export const SELECT_EMPTY_VALUE = "selecione";
