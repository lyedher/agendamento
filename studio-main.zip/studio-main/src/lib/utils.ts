import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { type Team, type Schedule, type Ac4Rates, type Ac4Calculation, type TeamHistoryEntry } from "./types";
import { addMinutes, differenceInMinutes } from "date-fns";
import { formatInTimeZone, toZonedTime } from "date-fns-tz";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export const TIME_ZONE = 'America/Sao_Paulo';

/**
 * Converte um horário vindo do banco (UTC) para o horário local de Brasília
 */
export const getLocalTime = (isoString: string | undefined): string => {
    if (!isoString) return 'N/A';
    try {
        return formatInTimeZone(new Date(isoString), TIME_ZONE, 'HH:mm');
    } catch (e) {
        return '--:--';
    }
};

export const isSameDayInTz = (date1: Date | string, date2: Date | string): boolean => {
    try {
        const d1 = typeof date1 === 'string' ? new Date(date1) : date1;
        const d2 = typeof date2 === 'string' ? new Date(date2) : date2;
        const f1 = formatInTimeZone(d1, TIME_ZONE, 'yyyy-MM-dd');
        const f2 = formatInTimeZone(d2, TIME_ZONE, 'yyyy-MM-dd');
        return f1 === f2;
    } catch {
        return false;
    }
}

export const getEquipeDoDia = (date: Date): Team => {
    const startDate = new Date('2025-09-01T12:00:00Z'); 
    const rotation: Team[] = ['CHARLIE', 'DELTA', 'ALPHA', 'BRAVO'];
    
    const dateInSP = toZonedTime(date, TIME_ZONE);
    const targetDate = new Date(Date.UTC(dateInSP.getFullYear(), dateInSP.getMonth(), dateInSP.getDate(), 12, 0, 0));

    const diff = Math.floor((targetDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const teamIndex = ((diff % 4) + 4) % 4;
    return rotation[teamIndex];
}

export function getTeamForDate(teamHistory: TeamHistoryEntry[] | undefined, date: Date): Team | 'N/A' {
    if (!teamHistory || teamHistory.length === 0) return 'N/A';
    const sortedHistory = [...teamHistory].sort((a, b) => new Date(b.effectiveDate).getTime() - new Date(a.effectiveDate).getTime());
    const targetDateStr = formatInTimeZone(date, TIME_ZONE, 'yyyy-MM-dd');
    const currentEntry = sortedHistory.find(entry => {
        const entryDateStr = formatInTimeZone(new Date(entry.effectiveDate), TIME_ZONE, 'yyyy-MM-dd');
        return entryDateStr <= targetDateStr;
    });
    return currentEntry ? currentEntry.team : 'N/A';
}

export const calculateAc4 = (schedule: Schedule & { isExternal?: boolean }, rates: Ac4Rates): Ac4Calculation | null => {
    try {
        const start = new Date(schedule.startTime);
        const end = new Date(schedule.endTime);
        if (isNaN(start.getTime()) || isNaN(end.getTime())) throw new Error('Invalid times');
        const durationInMinutes = differenceInMinutes(end, start);
        if (durationInMinutes <= 0) return null;
        
        const details: Ac4Calculation['details'] = [];
        let totalValue = 0;
        const minuteCounts = { blueDay: 0, blueNight: 0, redDay: 0, redNight: 0 };
        
        for (let i = 0; i < durationInMinutes; i++) {
            const currentMinute = addMinutes(start, i);
            const hour = parseInt(formatInTimeZone(currentMinute, TIME_ZONE, 'H'));
            const dayOfWeek = parseInt(formatInTimeZone(currentMinute, TIME_ZONE, 'i')); 
            
            const isRedScale = dayOfWeek === 5 || dayOfWeek === 6 || dayOfWeek === 7;
            const isNightTime = hour < 5 || hour >= 22;
            
            if (isRedScale) {
                if (isNightTime) minuteCounts.redNight += 1;
                else minuteCounts.redDay += 1;
            } else {
                if (isNightTime) minuteCounts.blueNight += 1;
                else minuteCounts.blueDay += 1;
            }
        }
        
        const addDetail = (type: keyof typeof minuteCounts, rate: number) => {
            const hours = minuteCounts[type] / 60;
            if (hours > 0) {
                const value = hours * rate;
                totalValue += value;
                details.push({ type: type as any, hours: parseFloat(hours.toFixed(2)), value });
            }
        };
        
        addDetail('blueDay', rates.blueDay);
        addDetail('blueNight', rates.blueNight);
        addDetail('redDay', rates.redDay);
        addDetail('redNight', rates.redNight);
        
        return { scheduleName: schedule.scheduleName, startTime: schedule.startTime, totalValue: totalValue, details, isExternal: !!schedule.isExternal };
    } catch (e) { return null; }
}

export const capitalizeName = (name: string) => {
  if (!name) return '';
  const exceptions = ['de', 'do', 'da', 'dos', 'das'];
  return name.toLowerCase().split(' ').map((word, index) => (index > 0 && exceptions.includes(word)) ? word : word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
};