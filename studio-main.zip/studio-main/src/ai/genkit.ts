// @ts-ignore
import {genkit} from 'genkit';
// @ts-ignore
import {googleAI} from '@genkit-ai/googleai';

export const ai = genkit({
  plugins: [googleAI()],
  model: 'googleai/gemini-2.5-flash',
});