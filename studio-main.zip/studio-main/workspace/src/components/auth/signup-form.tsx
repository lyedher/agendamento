'use client';

import { useActionState, useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import type { z } from 'zod';
import { Loader2, UserCircle, AlertCircle, CheckCircle } from 'lucide-react';
import { useFormStatus } from 'react-dom';
import Link from 'next/link';

import { signupAction } from '@/lib/actions';
import { SignupSchema, maskFunctions } from '@/lib/schemas';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { readAndCompressImage } from 'browser-image-resizer';
import { useToast } from '@/hooks/use-toast';
import { JOB_FUNCTION_NAMES, TEAM_NAMES, SELECT_EMPTY_VALUE, RANK_NAMES } from '@/lib/types';

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button
      type="submit"
      className="w-full"
      disabled={pending}
      style={{ backgroundColor: 'var(--accent)', color: 'var(--accent-foreground)' }}
    >
      {pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
      Criar conta
    </Button>
  );
}

type SignupFormValues = z.infer<typeof SignupSchema>;

export function SignupForm() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [isPhotoLoading, setIsPhotoLoading] = useState(false);
  const { toast } = useToast();

  const [state, formAction] = useActionState(signupAction, {
    message: '',
    success: false,
  });

  const form = useForm<SignupFormValues>({
    resolver: zodResolver(SignupSchema),
    defaultValues: {
      photo: '',
      rank: SELECT_EMPTY_VALUE,
      rg: '',
      nickname: '',
      fullName: '',
      jobFunction: SELECT_EMPTY_VALUE,
      workTeam: SELECT_EMPTY_VALUE,
      taxId: '',
      phone: '',
      email: '',
      password: '',
      presentationDate: undefined,
    },
  });
  
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    fieldName: keyof SignupFormValues
  ) => {
    const { value } = e.target;
    const mask = maskFunctions[fieldName as keyof typeof maskFunctions];
    const maskedValue = mask ? mask(value) : value;
    form.setValue(fieldName, maskedValue, { shouldValidate: true });
  };

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsPhotoLoading(true);
      try {
        const config = {
          quality: 0.7,
          maxWidth: 800,
          maxHeight: 800,
          autoRotate: true,
          debug: false,
        };
        const resizedImage = await readAndCompressImage(file, config);
        const reader = new FileReader();
        reader.onloadend = () => {
          const dataUrl = reader.result as string;
          setPhotoPreview(dataUrl);
          form.setValue('photo', dataUrl);
          setIsPhotoLoading(false);
        };
         reader.onerror = () => {
           toast({
            variant: 'destructive',
            title: 'Erro',
            description: 'Não foi possível processar a imagem.',
           });
           setIsPhotoLoading(false);
        }
        reader.readAsDataURL(resizedImage);
      } catch (error) {
        toast({
          variant: 'destructive',
          title: 'Erro de Imagem',
          description: 'Houve um problema ao redimensionar a imagem. Tente uma imagem diferente.',
        });
        setIsPhotoLoading(false);
      }
    }
  };
  
  if (state.success) {
    return (
        <Alert variant="default" className="border-green-500 bg-green-50 text-green-800">
          <CheckCircle className="h-4 w-4 text-green-500" />
          <AlertTitle>Sucesso!</AlertTitle>
          <AlertDescription>
            {state.message}
            <Link href="/" className="font-bold text-primary underline ml-1">
              Clique aqui para fazer o login.
            </Link>
          </AlertDescription>
        </Alert>
    );
  }

  return (
    <Form {...form}>
      <form action={(formData) => {
        const presentationDate = form.getValues('presentationDate');
        if (presentationDate) {
            formData.set('presentationDate', presentationDate.toISOString());
        } else {
            formData.delete('presentationDate');
        }
        formAction(formData);
      }} className="space-y-4">
       {state.message && !state.success && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Erro no Cadastro</AlertTitle>
            <AlertDescription>{state.message}</AlertDescription>
          </Alert>
        )}
        <div className="flex flex-col items-center space-y-4">
          <Avatar className="h-24 w-24">
            <AvatarImage src={photoPreview || ''} alt="Foto do perfil" />
            <AvatarFallback>
              {isPhotoLoading ? <Loader2 className="h-12 w-12 animate-spin" /> : <UserCircle className="h-24 w-24 text-muted-foreground" />}
            </AvatarFallback>
          </Avatar>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handlePhotoChange}
            className="hidden"
            accept="image/*"
          />
          <Button
            type="button"
            variant="link"
            onClick={() => fileInputRef.current?.click()}
            className="text-primary"
            disabled={isPhotoLoading}
          >
            {isPhotoLoading ? 'Processando...' : 'Inserir foto'}
          </Button>
          <FormField
            control={form.control}
            name="photo"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <Input type="hidden" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="space-y-4">
            <FormField
                control={form.control}
                name="rank"
                render={({ field }) => (
                    <FormItem>
                        <FormLabel>Posto/Graduação</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                                <SelectTrigger>
                                    <SelectValue placeholder="Selecione..."/>
                                </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                                <SelectItem value={SELECT_EMPTY_VALUE}>Selecione...</SelectItem>
                                {RANK_NAMES.map(rank => (
                                    <SelectItem key={rank} value={rank}>{rank}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <FormMessage />
                    </FormItem>
                )}
            />
          <FormField
            control={form.control}
            name="rg"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Identidade</FormLabel>
                <FormControl>
                  <Input
                    placeholder="00.000.000-0"
                    {...field}
                    onChange={(e) => handleInputChange(e, 'rg')}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="nickname"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome de Guerra</FormLabel>
                <FormControl>
                  <Input placeholder="Seu nome de guerra" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="fullName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome Completo</FormLabel>
                <FormControl>
                  <Input placeholder="John Doe" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
           <FormField
              control={form.control}
              name="jobFunction"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Função</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma função..." />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value={SELECT_EMPTY_VALUE}>Nenhuma</SelectItem>
                      {JOB_FUNCTION_NAMES.map((job) => (
                        <SelectItem key={job} value={job}>
                          {job}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
           <FormField
              control={form.control}
              name="workTeam"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Equipe de Trabalho</FormLabel>
                   <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                            <SelectTrigger>
                                <SelectValue placeholder="Nenhuma"/>
                            </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                            <SelectItem value={SELECT_EMPTY_VALUE}>Nenhuma</SelectItem>
                            {TEAM_NAMES.map(team => (
                                <SelectItem key={team} value={team}>{team}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          <FormField
            control={form.control}
            name="taxId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>CPF</FormLabel>
                <FormControl>
                  <Input
                    placeholder="000.000.000-00"
                    {...field}
                    onChange={(e) => handleInputChange(e, 'taxId')}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Telefone</FormLabel>
                <FormControl>
                  <Input
                    placeholder="(00) 00000-0000"
                    {...field}
                    onChange={(e) => handleInputChange(e, 'phone')}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>E-mail</FormLabel>
                <FormControl>
                  <Input type="email" placeholder="nome@exemplo.com" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Senha</FormLabel>
              <FormControl>
                <Input type="password" placeholder="••••••••" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        </div>
        <SubmitButton />
      </form>
    </Form>
  );
}
